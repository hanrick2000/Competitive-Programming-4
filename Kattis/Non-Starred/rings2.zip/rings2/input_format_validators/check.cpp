#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;

const int MAXS = 100;

const int EMPTY = 0;
const int TREE = 1;

int grid[MAXS+2][MAXS+2];

int fill(int i, int j)
{
	if (grid[i][j] == EMPTY)
		return 0;
	grid[i][j] = EMPTY;
	return 1 + fill(i+1,j) + fill(i-1,j) + fill(i,j+1) + fill(i,j-1);
}

int main()
{
	int n, m;
	string s;

	cin >> n >> m;
		if (n < 1 || n > MAXS) {
			cout << "ERROR: invalid n " << n << endl; return 1; }
		if (m < 1 || m > MAXS) {
			cout << "ERROR: invalid m " << m << endl; return 2; }
		for(int i=0; i<n+2; i++)
			for(int j=0; j<m+2; j++)
				grid[i][j] = EMPTY;
		int count = 0;
		int r=-1, c=-1;
		for(int i=1; i<=n; i++) {
			cin >> s;
			if (s.length() != m) {
				cout << "ERROR: line " << i << " incorrect length" << endl;
return 3;}
			for(int j=0; j<m; j++) {
				if (s[j] == 'T') {
					grid[i][j+1] = TREE;
					count++;
					r = i, c = j+1;
				}
				else if (s[j] != '.') {
					cout << "ERROR: invalid character " << s[j] << " in line " << i << endl; return 4;}
			}
		}
		int nfill = fill(r, c);
		if (nfill != count) {
			cout << "ERROR: squares do not make a connected section" << endl;
return 5;}
return 42;
}
