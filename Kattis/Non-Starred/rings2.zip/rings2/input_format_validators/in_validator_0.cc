#include <iostream>

using namespace std;

int grid[100][100]={0};

int visit(int r,int c) {

  grid[r][c] = 0;
  if (r-1 >= 0 && grid[r-1][c])
    visit(r-1,c);
  if (r+1 >= 0 && grid[r+1][c])
    visit(r+1,c);
  if (c-1 >= 0 && grid[r][c-1])
    visit(r,c-1);
  if (c+1 >= 0 && grid[r][c+1])
    visit(r,c+1);
}

int main(void) {
  int n,m,i,r=-1,c,j;
  string line;

  cin >> n >> m;
  if (!cin)
    return 1;
  // n and m between 1 and 100
  if (n <= 0 || n > 100)
    return 2;
  if (m <= 0 || m > 100)
    return 3;

  for (i=0;i<n;i++) {
    cin >> line;
    if (!cin)
      return 6;

    // line has m characters
    if (line.length() != m)
      return 7;
    // each character is T or .
    for (j=0;j<m;j++) {
      if (line[j] != 'T' && line[j] != '.')
        return 8;
      if (line[j] == 'T') {
        r = i;
        c = j;
        grid[i][j] = 1;
      }
    }
  }

  if (r != -1)
    visit(r,c);

  for (i=0;i<n;i++)
    for (j=0;j<m;j++)
      if (grid[r][c])
        return 9;

  // we win!
  return 42;
}

