// input checker probC - ECNA2015

#include <iostream>
using namespace std;

  int n,m;
  int r,c;
  int grid[102][102]={0};

void floodfill(int a, int b){
  if (a>0 && a<=n && b>0 && b<=m && grid[a][b]==2){
    grid[a][b]=1;
    floodfill(a-1,b);
    floodfill(a+1,b);
    floodfill(a,b-1);
    floodfill(a,b+1);
  }
}
 
bool IsConnected(){
  for(int i=1; i<=100; i++)
    for(int j=1; j<=100; j++)
      if (grid[i][j]==2)
        return false;
  return true;
}

int main(){

  char x;

  cin>>n>>m;
    if(n<1||n>100) { cout<<"n out of bounds"; return 1; }
    if (m<1||m>100) { cout<<"m out of bounds"; return 2; }
//    cleargrid();
    //place squares on grid
    for(int i=0;i<n;i++)
      for(int j=0;j<m;j++){
      cin>>x;
      if(x=='T') {
        grid[i+1][j+1]=2; 
        r=i+1, c=j+1;       //remember last spot
      }
      if(x!='T' && x!= '.') {cout<<" grid contains illegal char"; return 3; }
    }
    floodfill(r,c);

for (int i=0;i<n+2;i++) {
  for (int j=0;j<m+2;j++)
    cout << grid[i][j];
  cout << endl;
}

    if(!IsConnected()) { cout<<"section not connected"; return 4; }
    cout<<endl;

return 42;
}

